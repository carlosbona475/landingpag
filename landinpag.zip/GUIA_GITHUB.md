# 🚀 Guia: Subir AI PHARMA GUARD pro GitHub via Cursor

## Status atual do projeto

Seu repo já existe: `https://github.com/carlosbona475/AI-Pharma-Guard.git`
O `.gitignore` está correto e já exclui `.env`, `database.php` e `.htaccess`.

---

## PASSO 1 — Abrir o projeto no Cursor

1. Abra o **Cursor IDE**
2. Vá em **File → Open Folder**
3. Selecione a pasta `AI GUARD PHARM`

---

## PASSO 2 — Verificar o remote do Git

No terminal integrado do Cursor (`Ctrl+\` ou `Ctrl+J`):

```bash
git remote -v
```

Deve aparecer:
```
origin  https://github.com/carlosbona475/AI-Pharma-Guard.git (fetch)
origin  https://github.com/carlosbona475/AI-Pharma-Guard.git (push)
```

Se não aparecer, adicione:
```bash
git remote add origin https://github.com/carlosbona475/AI-Pharma-Guard.git
```

---

## PASSO 3 — Adicionar a landing page ao projeto

Copie o arquivo `landing-page.html` (melhorado) para a raiz do projeto,
substituindo o arquivo existente:

```bash
# Se o arquivo antigo existia na raiz, ele será substituído
cp /caminho/para/landing-page.html ./landing-page.html
```

Ou simplesmente arraste o arquivo para a pasta do projeto no Explorer do Cursor.

---

## PASSO 4 — Verificar o que será commitado

```bash
git status
```

Você verá os arquivos modificados. Verifique se **NÃO** aparecem:
- `.env`
- `backend/config/database.php`
- `.htaccess`

Se algum desses aparecer em vermelho, o `.gitignore` precisa ser verificado.

---

## PASSO 5 — Adicionar e commitar

```bash
# Adicionar todos os arquivos (o .gitignore protege os sensíveis)
git add .

# Verificar o que foi staged
git status

# Fazer o commit
git commit -m "feat: nova landing page + melhorias no projeto"
```

---

## PASSO 6 — Push para o GitHub

```bash
git push origin main
```

Se pedir autenticação, use seu **Personal Access Token** (PAT) do GitHub como senha.

**Para gerar um PAT:**
1. GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)
2. Generate new token → marque `repo`
3. Copie o token e use como senha no push

---

## PASSO 7 — Verificar no GitHub

Acesse: `https://github.com/carlosbona475/AI-Pharma-Guard`

A landing page deve aparecer como `landing-page.html` na raiz do projeto.

---

## 🔒 Arquivos sensíveis (NUNCA subir)

| Arquivo | Motivo |
|---------|--------|
| `.env` | Chaves de API, secrets |
| `backend/config/database.php` | Credenciais do banco |
| `.htaccess` | Configurações do servidor |
| `.env.txt` | Backup de credenciais |

Todos já estão no `.gitignore` ✅

---

## 🌐 Deploy da landing page no GitHub Pages (opcional)

Para hospedar a landing page gratuitamente no GitHub Pages:

1. No GitHub → repositório → **Settings → Pages**
2. Source: `main` branch → pasta `/` (root)
3. Save
4. Acesse: `https://carlosbona475.github.io/AI-Pharma-Guard/landing-page.html`

---

## 💡 Próximos commits sugeridos

```bash
# Depois de cada feature nova:
git add .
git commit -m "feat: descrição da funcionalidade"
git push origin main

# Para bugfixes:
git commit -m "fix: descrição do bug corrigido"

# Para documentação:
git commit -m "docs: atualiza README"
```
